function goHome() {
    window.location.href = 'file:///C:/Users/Zexyo/Desktop/ZexyoHQ%20site/index.html';  // Redirects to the homepage (adjust if needed)
}