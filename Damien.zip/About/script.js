function goHome() {
    window.location.href = 'https://zexyoo.github.io/Zexyo/'; // Redirects to home page
}
